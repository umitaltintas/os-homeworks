#include "MMU_Config.h"

MMU_Config::MMU_Config() = default;

MMU_Config::~MMU_Config() = default;

